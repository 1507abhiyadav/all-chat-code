import React from "react";

function CssPage() {
    return (
        <div className="htmlPage" style={{ border: "1px solid", color: "white", boxShadow: "2px 2px gray", backgroundColor: "blueviolet", width: "20%", height: "300px", margin: "10px", padding: "10px", borderRadius: "10px" }}>
            <span style={{ fontSize: "20px", color: "black" }}>Course of CSS</span>
            <ol><a href="https://www.w3schools.com/css/css_intro.asp"><li style={{color:"white"}}>introduction of CSS</li></a>
                <a href="https://www.w3schools.com/css/css_selectors.asp"><li style={{color:"white"}}> CSS Selector</li></a>
                <a href="https://www.w3schools.com/css/css_border.asp"> <li style={{color:"white"}}> CSS Borders</li></a>
                <a href="https://www.w3schools.com/css/css_positioning.asp"> <li style={{color:"white"}}> CSS Position</li></a>
                <a href="https://www.w3schools.com/css/css_table.asp"> <li style={{color:"white"}}>CSS table</li></a>
            </ol>
        </div>
    )
}

export default CssPage;