import React from "react";
import CssPage from "./CssPage";
import HtmlPage from "./HtmlPage";


function Home(){
    return(
    <div className="home" style={{display:"flex", alignItems:"center",justifyContent:"center"}}>
     <HtmlPage/>
     <CssPage/>
    
    </div>
    )
};

export default Home;