import React from "react";

function HtmlPage() {
    return (
        <div className="htmlPage" style={{ border: "1px solid", color: "white", boxShadow: "2px 2px gray", backgroundColor: "blueviolet", width: "20%", height: "300px", margin: "10px", padding: "10px", borderRadius: "10px" }}>
            <span style={{ fontSize: "20px", color: "black" }}>Course of HTML</span>
            <ol>
            <a href="https://www.w3schools.com/html/html_intro.asp"><li style={{color:"white"}}>introduction of HTML</li></a>
            <a href="https://www.w3schools.com/html/html_elements.asp"><li style={{color:"white"}}> HTML element</li></a>
            <a href="https://www.w3schools.com/html/html_headings.asp"><li style={{color:"white"}}>HTML Heading</li></a>
            <a href="https://www.w3schools.com/html/html_forms.asp"><li style={{color:"white"}}> HTML form</li></a>
            <a href="https://www.w3schools.com/html/html_tables.asp"><li style={{color:"white"}}> HTML table</li></a>
            </ol>
        </div>
    )
}

export default HtmlPage;