import Auth from "./Auth";
import{BrowserRouter, Route, Routes} from"react-router-dom";

import Home from "./pages/Home";
function App() {
  return (
    // <div className="App">
    //  <Auth/>
    // </div>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Auth/>}></Route>
        <Route path="/home" element={<Home/>}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
