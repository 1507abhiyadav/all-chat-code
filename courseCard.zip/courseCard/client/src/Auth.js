import React, { useState } from "react";
import "./Auth.css"
// import { useDispatch } from 'react-redux'
// import { logIn, signUp } from "./action/AuthAction";

function Auth() {

    const [isSignUp, setIsSignUp] = useState(true)

    const [data, setData] = useState({ firstname: "", lastname: "", username: "", password: "", Confirmpass: "" })
    const [Confirmpass, setConfirmpass] = useState(true)

    const handleChange = (e) => {
        setData({ ...data, [e.target.name]: e.target.value })
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(data);

        if (isSignUp) {
            fetch("http://localhost:5000/",
            {
                method:"POST",
                headers:{
                    "Content-Type":"application/json",
                    Accept:"application/json",
                },
                body:JSON.stringify({
                    data
                }),
            }).then((res)=>res.json).then((dat)=>
                console.log(dat,"userRegister"))
            }
          
            if (data.password !== data.Confirmpass) {
                setConfirmpass(false)
            }
            //     data.password===data.Confirmpass 
            //     ?dispatch(signUp(data))
            //     :setConfirmpass(false)
        }
        // else{
        //     dispatch(logIn(data))
        // }

    const restForm = () => {
        setConfirmpass(true)
        setData({ firstname: "", lastname: "", username: "", password: "", Confirmpass: "" })
    }
   return (
        <div className="Auth">
            <h1>Course of HTML and CSS</h1>
            <form className="infoForm" onSubmit={handleSubmit}>
                <h3>{isSignUp ? "Sign Up" : "Log In"}</h3>

                <div className="Ininput">
                    {isSignUp &&
                        <>
                            <input
                                type="text"
                                placeholder="First Name"
                                className="infoInput"
                                name="firstname"
                                onChange={handleChange}
                                value={data.firstname}
                            />
                            <input
                                type="text"
                                placeholder="Last Name"
                                className="infoInput"
                                name="lastname"
                                onChange={handleChange}
                                value={data.lastname}
                            />
                        </>
                    }

                    <input
                        type="text"
                        placeholder="Username"
                        className="infoInput"
                        name="username"
                        onChange={handleChange}
                        value={data.username}
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        className="infoInput"
                        name="password"
                        onChange={handleChange}
                        value={data.password}
                    />
                    {isSignUp &&
                        <input
                            type="password"
                            placeholder="Confirm Password"
                            className="infoInput"
                            name="Confirmpass"
                            onChange={handleChange}
                            value={data.Confirmpass}
                        />
                    }

                </div>
                <span style={{ display: Confirmpass ? "none" : "block", color: "red", }}>
                    * Confirm password is not same
                </span>
                <div>
                    <span style={{ fontSize: "17px", cursor: "pointer" }} onClick={() => { setIsSignUp((prev) => !prev); restForm() }}>
                        {isSignUp ? "Alredy have an account. Login!" : "Don't have an account? Sign up"}</span>
                </div>
                <button className="infoButton" type="submit">{isSignUp ? "Signup" : "Login"}</button>
            </form>

        </div>

    )
}



export default Auth;

// alignSelf:"flex-end"