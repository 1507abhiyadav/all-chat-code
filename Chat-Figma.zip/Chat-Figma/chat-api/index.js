const http= require("http");
const express= require("express");
const cors= require("cors");
const mongoose = require("mongoose");
const socketIO= require("socket.io");
const app= express();
const port= 5000  || process.env.PORT ;

app.use(cors());
app.get("/",(req,res)=>{
    res.send("hello")
})

const server = http.createServer(app);
const io = socketIO(server);
io.on("connection",()=>{
    console.log('new Connection');
})

server.listen(port,()=>{
    console.log(`server is listening on http://localhost:${port}`);
})



