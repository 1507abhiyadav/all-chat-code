import React from "react";
import Register from "./Register";
import Login from "./Login";
import Header from "../components/Header";
import MainContain from "../components/MainContain";


function Home() {
  return (
   <div className="home">
    <Header/>
    <MainContain/>
    </div>
  
  );
}

export default Home;
