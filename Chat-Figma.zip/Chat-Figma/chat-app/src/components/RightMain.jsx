import React from "react";
import "./RightMain.css";

function RightMain() {
  return (
    <>
      <div className="rightContainer">
        <div className="rightContHeader">
          <span>Latest Photos</span>
          <button>VIEW ALL</button>
        </div>
        <div className="rightImgBox">
          <div className="rowimg">
            <div className="imgRight"><img src="https://imageio.forbes.com/specials-images/dam/imageserve/1147545116/960x0.jpg" alt="" style={{ width: "80px", height: "70px" }} /></div>
            <div className="imgRight"><img src="https://cdn.pixabay.com/photo/2014/09/14/18/04/dandelion-445228__480.jpg" alt="" style={{ width: "80px", height: "70px" }} /></div>
            <div className="imgRight"><img src="https://imageio.forbes.com/specials-images/dam/imageserve/1147545116/960x0.jpg" alt="" style={{ width: "80px", height: "70px" }} /></div>
          </div>
          <div className="colimg">
            <div className="imgRight"><img src="https://cdn.pixabay.com/photo/2014/09/14/18/04/dandelion-445228__480.jpg" alt="" style={{ width: "80px", height: "70px" }} /></div>
            <div className="imgRight"><img src="https://imageio.forbes.com/specials-images/dam/imageserve/1147545116/960x0.jpg" alt="" style={{ width: "80px", height: "70px" }} /></div>
            <div className="imgRight"><img src="https://cdn.pixabay.com/photo/2014/09/14/18/04/dandelion-445228__480.jpg" alt="" style={{ width: "80px", height: "70px" }} /></div>
          </div>
        </div>
        <div className="rightContHeader">
          <span>Latest Photos</span>
          <button>VIEW ALL</button>
        </div>
        <div className="imgStatemet">
          <div style={{ margin: "10px" }}>
            <i class="fa fa-envelope"></i>
            <span style={{margin:"10px"}}>Fashion clothing ideas</span>
          </div>
          <div style={{ margin: "10px" }}>
            <i class="fa fa-envelope"></i>
            <span style={{margin:"10px"}}>Web Presentation</span>
          </div>
          <div style={{ margin: "10px" }}>
            <i class="fa fa-envelope"></i>
            <span style={{margin:"10px"}}>Converted files</span>
          </div>
          <div style={{ margin: "10px" }}>
            <i class="fa fa-envelope"></i>
            <span style={{margin:"10px"}}>Logo and brandimg </span>
          </div>
          <div style={{ margin: "10px" }}>
            <i class="fa fa-envelope"></i>
            <span style={{margin:"10px"}}>Brandimg image</span>
          </div>
          <div>
          </div>
        </div>
      </div>
    </>

  );
}

export default RightMain;
;