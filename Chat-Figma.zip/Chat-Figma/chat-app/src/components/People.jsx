import React from "react";
import "./People.css";
// import  ReactDOM  from "react-dom";

function People() {
    const currTime = new Date().toLocaleTimeString()
    // alert(currTime)
    // const date = new Date();
    // const currTime = date.getHours() 
    //     + ':' + date.getMinutes();
    let peoples = [{
        "msg": [{
            "text": "hello",
            "msgTime": "5:12",
        }, {
            "text": "hello22",
            "msgTime": "5:12",
        }, {
            "text": "hello1",
            "msgTime": "5:12",
        }, {
            "text": "hello22345",
            "msgTime": "5:12",
        }],
        "name": "Abhishek",
        "address": "bdhj",
        "id": 1,
        "email": "abhi@gamil.com"
    }, {
        "name": "reka",
        "address": "azg",
        "id": 2,
        "email": "raka@gamil.com",
        "msg": [{
            "text": "hello",
            "msgTime": "5:12",
        }, {
            "text": "hello",
            "msgTime": "5:12",
        }, {
            "text": "hello1",
            "msgTime": "5:12",
        }, {
            "text": "hello2",
            "msgTime": "5:12",
        }]
    }, {
        "name": "nity",
        "address": "deo",
        "id": 3,
        "email": "nitya@gamil.com",
        "msg": [{
            "text": "hello",
            "msgTime": "5:12",
        }, {
            "text": "hello",
            "msgTime": "5:12",
        }, {
            "text": "hello1",
            "msgTime": "5:12",
        }, {
            "text": "hello2",
            "msgTime": "5:12",
        }]
    }
    ]


    return (
        <div>
            {peoples.map((items) => {
                return (
                    <div className="ProfileContainer">
                        <div className="imgCon">
                            <img src="https://c4.wallpaperflare.com/wallpaper/860/395/693/nature-autumn-wallpaper-preview.jpg" alt="" />
                        </div>
                        <div className="ChatInfo" >
                            <span className=""><b>{items.name}</b></span><br />
                            <span>{items.msg[items.msg.length-1].text}</span>
                        </div>
                        <div className="btnInfo">
                            <span className="mes">5:30 AM</span>
                            <img className="signIcon" src="https://thumb7.shutterstock.com/mosaic_250/169597876/569987260/stock-vector-vector-illustration-of-tick-icon-in-blue-569987260.jpg" alt="" />
                        </div>
                    </div>
                )
            })
            }

        </div>
    )
}
export default People;