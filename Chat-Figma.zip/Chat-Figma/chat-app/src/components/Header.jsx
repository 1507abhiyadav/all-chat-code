import React from "react";
import "./Header.css"
function Header(){
    // const handleChange=(event)=>{

    // }
    // onChange={(e)=>handleChange(e)}


    return(
        <div className="header">
            <div className="name">ambaram</div>
            <div className="inputBox">
                <div className="all">All</div>
                <div className="inputS"><input placeholder="Search" ></input>
                <i class="fa fa-search"></i>
                </div>
            </div>
            <div className="create">
                <select>
                    <option>Create</option>
                </select>
            </div>
            <div className="profileImg">
                {/* <select>
                <option> */}
                    <img  className="Img" src="https://upload.wikimedia.org/wikipedia/commons/c/c0/Official_Photograph_of_Prime_Minister_Narendra_Modi_Potrait.png" alt=""/>
                {/* </option>
                </select> */}
            </div>
        </div>
    )
}
export default Header;