import React, { useState } from "react";
import "./MiddleMain.css";

function MiddleMain() {
  const [image, setImage] = useState();
  console.log(image);
  const currTime = new Date().toLocaleTimeString();

  let data = {
    "name": "nity",
    "address": "deo",
    "id": 3,
    "email": "nitya@gamil.com",
    "msg": [{
      "isSent": false,
      "text": "hello",
      "msgTime": "5:12",
    }, {
      "isSent": true,
      "text": "hello11",
      "msgTime": "5:12",
    }, {
      "isSent": true,
      "text": "hello2222",
      "msgTime": "5:12",
    }, {
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },
    {
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },
    {
      "isSent": true,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": true,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": true,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": true,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": true,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": true,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": true,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    },{
      "isSent": false,
      "text": "hello333",
      "msgTime": "5:12",
    }]
  }
  return (
    <>
      <div className="mainBody">
        <div className="SenderReceiverBox ">
          {data.msg.map((ele) => {
            {/* console.log(ele.isSent) */ }
            return (
              <>
                {ele.isSent ?
                  <div className="Sent">
                    <div className="chatSent">
                      <p className="chatMessageSent"> {ele.text}</p>
                      <img className="sentImg" src="https://upload.wikimedia.org/wikipedia/commons/c/c0/Official_Photograph_of_Prime_Minister_Narendra_Modi_Potrait.png" alt="" />
                    </div>
                    <span className="senderTime">{currTime}</span>
                  </div>
                  :
                  <div className="Received ">
                    <div className="chatReceived">
                      <img src="https://upload.wikimedia.org/wikipedia/commons/c/c0/Official_Photograph_of_Prime_Minister_Narendra_Modi_Potrait.png" alt="" />
                      <p className="chatMessageReceived">{ele.text}</p>
                    </div>
                    <span className="receiverTime">{currTime}</span>
                  </div>

                }

              </>

            )
          })}
        </div>
        <div className="sendChatBoxInput">
          <div className="ChatBoxInputImg">
            <div className="chatSms">
              <input placeholder="Your message"></input>
            </div>
            <div className="icons">
              <label htmlFor="imgs">
                <img className="att" src="https://www.iconbunny.com/icons/media/catalog/product/9/6/969.9-attachment-icon-iconbunny.jpg" alt="" />
              </label>
              <input id="imgs" type="file" accept="image/png,image/jpeg,.txt,.doc" onChange={(e) => setImage(e.target.files)} />
              <img src="http://cdn.onlinewebfonts.com/svg/img_139349.png" alt="" />
              <img src="https://cdn-icons-png.flaticon.com/512/1500/1500458.png" alt="" />
              <img className="imgSend" src="https://img.icons8.com/external-inkubators-detailed-outline-inkubators/512/external-send-ecommerce-user-interface-inkubators-detailed-outline-inkubators.png" alt="" />
            </div>
          </div>
        </div>
        
      </div>
    </>

  );
}

export default MiddleMain;
;