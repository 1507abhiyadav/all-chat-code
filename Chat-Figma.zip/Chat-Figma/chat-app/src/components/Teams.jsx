import React from "react";
import "./Teams.css"

let teams = [
    {
        "name": "zoomMeeting",
        "img": "don"
    }, {
        "name": "GoogleMeeting",
        "img": "hero"
    }, {
        "name": "whatsappMeeting",
        "img": "don"
    }
]

function Teams() {
    return (
        <div>
            {teams.map((ele => {
                return (
                    <div className="teams">
                        <div className="imgTeams">
                            <img src="https://cdn.iconscout.com/icon/premium/png-256-thumb/finance-teams-6083574-5108988.png" alt="" />
                        </div>
                        <div className="nameTeams"> {ele.name} </div>
                    </div>

                )
            }))}


        </div>
    )
};

export default Teams;