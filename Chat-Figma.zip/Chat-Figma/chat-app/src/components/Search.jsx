import React from "react";


function Search() {
  return (
   <div className="search">
    <div className="searchForm">
        <input  type="text" placeholder="search"/>
    </div>
    <div className="userChat">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/c0/Official_Photograph_of_Prime_Minister_Narendra_Modi_Potrait.png" alt="" />
        <div className="userChatInfo">
            <span>Modi</span>
        </div>
    </div> 
   </div>
  );
}

export default Search;