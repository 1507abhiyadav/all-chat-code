import React from "react";


function Input() {
  return (
   <div className="input">
    <input type="text" placeholder="Type something..."/>
    <div className="send">
        <img src="https://img.icons8.com/material-outlined/512/attach.png" alt="Attach" width={30} height={30}/>
        <input type="file" style={{display:"none"}} id="file" />
        <label htmlFor="file">
            <img src="https://img.icons8.com/ios-glyphs/2x/add-image.png" alt="Add Image" width={30} height={30}/>
        </label>
        {/* <button>Send</button> */}
        <img src="https://img.icons8.com/external-bartama-outline-32-bartama-graphic/512/external-email-e-mail-bartama-outline-32-bartama-graphic-7.png" alt="Send" width={30} height={30}/> 
    </div>
   </div>
  );
}

export default Input;