import React from "react";
import ChatHeader from "./ChatHeader";
import LeftMain from "./LeftMain";
import MiddleMain from "./MiddleMain";
import RightMain from "./RightMain";
import "./MainContain.css"

function MainContain(){
    return (
        <div className="body">
            <ChatHeader/>
            <div className="bodyContain">
            <LeftMain/>
            <MiddleMain/>
            <RightMain/>
            </div>
        </div>
    )

}
export default MainContain;
