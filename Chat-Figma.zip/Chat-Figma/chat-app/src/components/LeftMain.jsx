import React, { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import "./LeftMain.css";
import People from "./People";
import Teams from "./Teams";

function LeftMain() {
  const [diableTeam, setDiableTeam] = useState(true)
  const toggleOption = () => {
    setDiableTeam(!diableTeam)
  }
  return (
    <>
      <div className="leftmain">
        <div >
          <input className="input" type="text" placeholder="Search"  style={{color:"black",}}/>
        </div>
        <div className="favo">
          <span>FAVORITES</span>
        </div>
        <div className="icon">

          <img className="addIcon" src="https://cdn3.iconfinder.com/data/icons/eightyshades/512/14_Add-1024.png" alt="" />
          <div className="imgs">
            <img className="img" src="https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8bGFkeXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=600&q=60" alt="" />
            <img className="img" src="https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8bGFkeXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=600&q=60" alt="" />
            <img className="img" src="https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8bGFkeXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=600&q=60" alt="" />
            <div className="imgOnline"></div>

          </div>
        </div>
        <div>
          <div className="People">
            <span className="toggleoption" onClick={toggleOption}>People</span>
            <span className="toggleoption" onClick={toggleOption}>Team</span></div>
        </div>
        {/* <div className="eachPeople">
          <People />
        </div> */}
        {diableTeam? <People/>:<Teams/>}

        <div className="call">
          <div className="voiceCall">
            <button>
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoSvmnm5Xat2eUJ2qZijUrweZS0pueSDBHnQ&usqp=CAU" alt="" />
              <p>VOICE CALL</p>
            </button>
          </div>
          <div className="videoCall">
            <button>
              <img src="https://www.clipartmax.com/png/middle/214-2144865_video-call-icon-video-call-icon-png.png" alt="" />
              <p>VIDEO CALL</p>
            </button>
          </div>
        </div>
      </div>

    </>

  );
}

export default LeftMain;