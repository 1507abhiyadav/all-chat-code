import React from "react";


function Message() {
    const date = new Date().toLocaleDateString()
  return (
   <div className="message">
   {/* <div className="messageInfo">
   <img src="http://upcmo.up.nic.in/images/ADITYANATH_YOGI_CMUP.jpg" alt=""/>
   <span>{date}</span>
   </div>
   <div className="messageContent">
    <p>hello</p>
    <img src="https://pbs.twimg.com/profile_images/1570349833277546497/I-SK-za7_400x400.jpg" alt=""/>
   </div> */}

   </div>
  );
}

export default Message;