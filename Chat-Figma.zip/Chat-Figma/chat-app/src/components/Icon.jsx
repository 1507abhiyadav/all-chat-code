import React from "react";
import "./Icon.css"
function Icon() {
  return (
    <div className="iconContainer">
    <div  className="icons"><i class="fa fa-bars"></i></div>
    <div  className="icons"><i class="fa fa-cloud"></i></div>
    <div  className="icons"><i class="fa fa-car"></i></div>
    <div  className="icons"><i class="fa fa-file"></i></div>
    <div  className="icons"><i class="fa fa-file"></i></div>
    <div  className="icons"><i class="fa fa-file"></i></div>
    <div  className="icons"><i class="fa fa-file"></i></div>
    <div  className="icons"><i class="fa fa-envelope"></i></div>
    <div  className="icons"><i class="fa fa-bell"></i></div>
    <div  className="icons"><i class="fa fa-calendar"></i></div>
    <div  className="icons"><i class="fa fa-envelope"></i></div> 

    </div>
    )
    }
export default Icon;