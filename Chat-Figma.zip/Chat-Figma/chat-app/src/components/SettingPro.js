import React from "react";

function SettingPro() {
    return (
        <div className="setting" style={{ boxShadow: "10px 5px Gray", width: "70%" }}>
            <div className="preference" style={{ display: "flex", gap: "5px", border: "1px solid red", alignItems: "center" }}>
                <img src="https://cdn-icons-png.flaticon.com/512/126/126472.png" alt="" style={{ width: "30px", height: "20px" }} />
                <h4>My preferences</h4>
            </div>
            <div className="contacts" style={{ display: "flex", gap: "5px", border: "1px solid red", alignItems: "center" }}>
                <img src="https://cdn.vectorstock.com/i/1000x1000/08/99/add-contacts-icon-vector-22390899.webp" alt="" style={{ width: "30px", height: "20px" }} />
                <h4>Active contacts</h4>
            </div>
            <div className="chats" style={{ display: "flex", gap: "5px", border: "1px solid red", alignItems: "center" }}>
                <img src="https://image.shutterstock.com/image-vector/file-folder-document-icon-vector-260nw-271331426.jpg" alt="" style={{ width: "30px", height: "20px" }} />
                <h4>Archived chats</h4>
            </div>
        </div>
    )
}

export default SettingPro;