import React, { useState } from "react";

import "./ChatHeader.css"
import SettingPro from "./SettingPro";


function ChatHeader() {

let[diableP,setDiableP]= useState(false)

let click=()=>{
setDiableP(true)
}



  return (
    <div className="chatHeader">

      <div className="chat">
        <h3>CHATS</h3>
        <i class="fa fa-gear" onClick={click}></i>
        {diableP? <SettingPro/>: ""}
      </div>

      <div className="nameImg">
      <div className="img">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/c0/Official_Photograph_of_Prime_Minister_Narendra_Modi_Potrait.png" alt=""></img>
        </div>
        <h3 className="user">Modi</h3>
      </div>

      <div className="chatAttchment">
        <h4>Chat Attchments</h4>
      </div>

    </div>
  );
}

export default ChatHeader;