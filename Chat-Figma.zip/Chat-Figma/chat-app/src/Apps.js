import React from "react";
import "./Apps.css";
import Icon from "./components/Icon";
import {BrowserRouter, Routes ,Route} from"react-router-dom";
import Home from "./pages/Home";

function Apps() {
  return (
   <>
   <div className="mainContainer">
    <div className="leftSide">
    <Icon/>
    </div>
    <div className="rightSide">
    <Home/>
    </div>
   </div>
 
   </>
  );
}

export default Apps;
